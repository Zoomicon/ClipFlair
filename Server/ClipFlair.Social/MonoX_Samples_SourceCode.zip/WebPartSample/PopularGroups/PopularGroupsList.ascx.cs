﻿using MonoSoftware.MonoX.Caching;
using MonoSoftware.MonoX.Repositories;
using MonoSoftware.MonoX.Resources;
using MonoSoftware.MonoX.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using NVelocity;

namespace MonoSoftware.MonoX.ModuleGallery.SocialNetworking
{
    /// <summary>
    /// Displays most popular groups ordered by their creation date, often used on dashboard pages. Inherits from the GroupListBasedPart.
    /// </summary>
    [WebPartCatalogCategory("Samples")]
    public partial class PopularGroupsList : GroupListBasePart
    {
        #region Properties
        /// <summary>
        /// Templated list view that is used for rendering the "repeatable" section of this control.
        /// </summary>
        [PersistenceMode(PersistenceMode.InnerProperty)]
        public ListView TemplatedControl
        {
            get { return lvItems; }
            set
            {
                pnlContainer.Controls.Remove(lvItems);
                lvItems = value;
                pnlContainer.Controls.AddAt(0, lvItems);
            }
        }

        /// <summary>
        /// Pager page size.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Pager page size")]
        [WebDisplayName("Pager page size")]
        public int PageSize
        {
            get { return pager.PageSize; }
            set { pager.PageSize = value; }
        }

        private bool _pagingEnabled = true;
        /// <summary>
        /// Gets or sets a value indicating whether paging is enabled.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Paging enabled")]
        [WebDisplayName("Paging enabled")]
        public bool PagingEnabled
        {
            get { return _pagingEnabled; }
            set { _pagingEnabled = value; }
        }

        private string _pagerQueryString = "PopularGroupsPageNo";
        /// <summary>
        /// Pager query string name.
        /// </summary>
        [WebBrowsable(true), Personalizable(true)]
        [WebDescription("Pager query string name")]
        [WebDisplayName("Pager query string name")]
        public string PagerQueryString
        {
            get { return _pagerQueryString; }
            set { _pagerQueryString = value; }
        } 
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor.
        /// </summary>
        public PopularGroupsList()
        {
            //Set the title that will be visible in the Module gallery so user can pick the module from the list
            Title = "Popular groups list";
            //Define the template root folder for where MonoX can search for specified template
            ControlSpecificTemplateSubPath = "SocialNetworkingTemplates";
            this.CatalogIconImageUrl = Paths.App_Themes.All.Common.img.parts.General.list_container_png;
            //Define the template file name (without the extension)
            Template = "PopularGroupsList";
            IsTemplated = true;
        } 
        #endregion

        #region Page Events
        protected override void OnInit(EventArgs e)
        {            
            //Set the SEO pager query string so pager can read the proper page number form the Url
            PagerUtility.SetCustomQueryStringName(this, pager, this.PagerQueryString);
            this.TemplatedControl.ItemDataBound += new EventHandler<ListViewItemEventArgs>(lvItems_OnItemDataBound);
            ltlNoData.Text = SocialNetworkingResources.Groups_NoDataWarning;
            base.OnInit(e);
        }

        protected override void OnLoad(EventArgs e)
        {            
            //Optimize the binding process
            if (this.Visible)
                BindData();
            base.OnLoad(e);
        }

        protected override void OnPreRender(EventArgs e)
        {            
            //Hide the pager if there are no pages or paging is disabled
            pager.Visible = (pager.PageCount > 1) && this.PagingEnabled;
            base.OnPreRender(e);
        } 
        #endregion

        #region Methods
        /// <summary>
        /// Binds and formats group data for display in the main list view control.
        /// </summary>
        [WebPartApplyChanges]
        public override void BindData()
        {
            //Optimize the DB access by using the MonoX cache mechanism (Note: To gain from this kind of optimization you need to set the CacheDuration for this web part)
            MonoXCacheManager cacheManager = MonoXCacheManager.GetInstance(CacheKeys.Groups.PopularGroupsList, this.CacheDuration);
            PagedCollectionContainer bindContainer = cacheManager.Get<PagedCollectionContainer>(PagedCollectionContainer.GetPagerCacheKey(pager)) ?? PagedCollectionContainer.GetInstance();
            if (!bindContainer.HasValue)
            {
                //Fetch the popular groups
                bindContainer.Collection = PopularGroupRepository.GetInstance().GetPopularGroups(String.Empty, Guid.Empty, pager.CurrentPageIndex + 1, pager.PageSize, out bindContainer.RecordCount);
                //Store the values to the cache (Note: If CacheDuration is set to "0" values are not saved to the cache)
                cacheManager.Store(bindContainer, PagedCollectionContainer.GetPagerCacheKey(pager));
            }
            //Perform the binding process that will automatically bind the control and pager
            PagerUtility.BindPager(pager, BindData, lvItems, bindContainer.Collection, bindContainer.RecordCount);
            ltlNoData.Visible = (bindContainer.RecordCount == 0);
        }

        protected void lvItems_OnItemDataBound(object sender, ListViewItemEventArgs e)
        {
            if (e.Item.ItemType == ListViewItemType.DataItem)
            {
                SnGroupDTO group = ((ListViewDataItem)e.Item).DataItem as SnGroupDTO;
                //Parse template tags will extract all the needed information from SnGroupDTO and fill the tags collection with tags that are built-in 
                //Note: To add any custom tags to web part template you need to override the ParseTemplateTags and add custom tags, then you need to place them in web part template file
                VelocityContext velocityContext = new VelocityContext();
                velocityContext.Put(ItemDataBoundEventArgs.ContainerParamName, new ItemDataBoundEventArgs(((ListViewDataItem)e.Item).DataItemIndex, group));
                Hashtable tags = ParseTemplateTags(group, velocityContext);
                //Render templated item to the place holder
                //Note: This built-in method will parse the provided html template and replace the tags with the values stored in the tags collection
                RenderTemplatedPart(e.Item, String.Empty, CurrentTemplateHtml, tags, velocityContext);
            }
        } 
        #endregion

   }
}
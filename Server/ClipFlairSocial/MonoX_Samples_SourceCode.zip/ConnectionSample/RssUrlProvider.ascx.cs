using System;
using System.Web.UI.WebControls.WebParts;

namespace MonoSoftware.MonoX.Samples
{
    public partial class RssUrlProvider : BasePart, IStringConnectionInterface
    {
        //private string _test;
        //[WebBrowsable(true), Personalizable(true), Category("test")]
        //[WebDescription("Test prop")]
        //[WebDisplayName("Test prop")]
        //public string Test
        //{
        //    get { return _test; }
        //    set { _test = value; }
        //}

        [ConnectionProvider("Rss URL Provider", "RssConnection")]
        public IStringConnectionInterface GetProviderData()
        {
            return this;
        }

        #region IStringConnectionInterface Members

        public string StringParameter
        {
            get { return txtUrl.Text; }
        }

        #endregion
    }

}
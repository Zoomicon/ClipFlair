﻿using MonoSoftware.Core;
using MonoSoftware.MonoX.Utilities;
using System;
using System.Web.UI.WebControls.WebParts;

namespace MonoSoftware.MonoX.Samples
{
    public partial class TestRelationshipProvider : BasePart, ISnRelationshipConnection
    {
        private Guid _parentId;
        public Guid ParentId
        {
            get 
            {
                if (GuidExtension.IsNullOrEmpty(_parentId))
                {
                    if (Session["MonoXTestRelationshipProviderId"] == null)
                    {
                        _parentId = GuidExtension.NewSequentialGuid();
                        MonoSoftware.MonoX.Repositories.RelationshipRepository.GetInstance().EnsureRelationshipExists(_parentId, SnEntityType.Custom1);
                        Session["MonoXTestRelationshipProviderId"] = _parentId;
                    }
                    else
                        _parentId = new Guid(Session["MonoXTestRelationshipProviderId"].ToString()); 
                }
                return _parentId; 
            }
            set { _parentId = value; }
        }

        [ConnectionProvider("SN relationship data provider", "RelationshipConnection")]
        public ISnRelationshipConnection GetProviderData()
        {
            return this;
        }


        #region ISnRelationshipConnection Members

        public Guid ParentEntityId
        {
            get 
            {
                return this.ParentId;
            }
        }

        public MonoSoftware.MonoX.Utilities.SnEntityType ParentEntityType
        {
            get { return SnEntityType.Custom1; }
        }

        #endregion
    }
}
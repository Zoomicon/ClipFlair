

namespace MonoSoftware.MonoX.Samples
{
    public partial class ConnectionSample : BasePage
    {
        //protected override void OnInit(EventArgs e)
        //{
        //    //example on how to work with custom categories in Web parts.
        //    IToolboxMasterPage mx = (IToolboxMasterPage)this.FindMasterWithToolbox();

        //    mx.EditorZone.Delete("propertyGridEditorPart");

        //    PropertyGridEditorPart test = new PropertyGridEditorPart();
        //    test.Title = "Show";
        //    test.ID = "testEditorPart";
        //    test.ShowCategories = "Test";
        //    mx.EditorZone.Insert(0, test);

        //    PropertyGridEditorPart test2 = new PropertyGridEditorPart();
        //    test2.Title = "Hide";
        //    test2.ID = "testCategorypart";
        //    test2.HideCategories = "Test";
        //    mx.EditorZone.Insert(1, test2);
        //    base.OnInit(e);
        //}

        //protected override void OnLoad(EventArgs e)
        //{
        //    WebPartManager wpm = WebPartManager.GetCurrentWebPartManager(this.Page);
        //    WebPartConnection c = new WebPartConnection();
        //    c.ID = "staticConnection";
        //    c.ConsumerConnectionPointID = "RelationshipConsumer";
        //    c.ConsumerID = "comments";
        //    c.ProviderConnectionPointID = "RelationshipConnection";
        //    c.ProviderID = "testProvider";
        //    wpm.StaticConnections.Add(c);
        //    base.OnLoad(e);
        //}
    }
}